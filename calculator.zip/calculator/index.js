const display = document.querySelector('input[name="display"]');

function deleteLast() {
    display.value = display.value.slice(0, -1);
}

function calculate() {
    try {
        display.value = eval(display.value);
    } catch (e) {
        display.value = 'Error'; 
    }
}

document.querySelectorAll('input[type="button"]').forEach(button => {
    if (button.value === "=") {
        button.addEventListener('click', calculate);
    } else if (button.value === "DE") {
        button.addEventListener('click', deleteLast);
    }
});
